import CameraControls from "camera-controls";
export declare function setupNavigation(cameraControls: CameraControls): void;
